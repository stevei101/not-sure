import React, { useRef } from 'react';
import { RAGDocument } from '../types';
import { FileText, X, Database, Plus } from 'lucide-react';

interface SidebarProps {
  documents: RAGDocument[];
  setDocuments: React.Dispatch<React.SetStateAction<RAGDocument[]>>;
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ documents, setDocuments, isOpen, toggleSidebar }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const newDocs: RAGDocument[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      // Basic text file reading. 
      // In a real production app, use specific parsers for PDF, Docx, etc.
      try {
        const text = await file.text();
        newDocs.push({
          id: crypto.randomUUID(),
          name: file.name,
          size: file.size,
          type: file.type,
          content: text
        });
      } catch (err) {
        console.error("Failed to read file", file.name, err);
        alert(`Could not read ${file.name}. Please upload text-based files (.txt, .md, .json, .csv)`);
      }
    }

    setDocuments(prev => [...prev, ...newDocs]);
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeDocument = (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
  };

  return (
    <div 
      className={`fixed inset-y-0 left-0 z-40 w-72 bg-surface border-r border-slate-700 transform transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0 lg:static lg:block`}
    >
      <div className="flex flex-col h-full p-4">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2 text-primary font-bold text-xl">
            <Database className="w-6 h-6" />
            <span>Knowledge Base</span>
          </div>
          <button onClick={toggleSidebar} className="lg:hidden text-slate-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3">
          {documents.length === 0 ? (
            <div className="text-center text-slate-500 py-10 px-4 border-2 border-dashed border-slate-700 rounded-lg">
              <p className="mb-2 text-sm">No context loaded.</p>
              <p className="text-xs">Upload text files to ground the AI in your specific data.</p>
            </div>
          ) : (
            documents.map(doc => (
              <div key={doc.id} className="group flex items-center justify-between p-3 bg-slate-800 rounded-lg border border-slate-700 hover:border-slate-500 transition-colors">
                <div className="flex items-center space-x-3 overflow-hidden">
                  <FileText className="w-4 h-4 text-accent flex-shrink-0" />
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm font-medium text-slate-200 truncate" title={doc.name}>{doc.name}</span>
                    <span className="text-xs text-slate-500">{(doc.size / 1024).toFixed(1)} KB</span>
                  </div>
                </div>
                <button 
                  onClick={() => removeDocument(doc.id)}
                  className="text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-slate-700">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileSelect} 
            className="hidden" 
            multiple 
            accept=".txt,.md,.json,.csv,.js,.ts,.html,.css"
          />
          <button 
            onClick={() => {
              if (fileInputRef.current) {
                fileInputRef.current.click();
              }
            }}
            className="w-full flex items-center justify-center space-x-2 bg-slate-700 hover:bg-slate-600 text-white py-3 rounded-lg transition-colors font-medium"
          >
            <Plus className="w-5 h-5" />
            <span>Add Sources</span>
          </button>
          <p className="text-center text-xs text-slate-500 mt-2">
            Supported: .txt, .md, .json, .csv, code
          </p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;