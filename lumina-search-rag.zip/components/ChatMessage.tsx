import React from 'react';
import { ChatMessage, GroundingSource } from '../types';
import { User, Bot, Globe } from 'lucide-react';

const FormattedText: React.FC<{ text: string }> = ({ text }) => {
  // Manual markdown parsing for bold, code blocks, and simple text structure.
  // Splits by triple backticks for code blocks.
  const parts = text.split(/(```[\s\S]*?```)/g);
  
  return (
    <div className="markdown-body text-sm md:text-base leading-relaxed text-slate-300">
      {parts.map((part, i) => {
        if (part.startsWith('```')) {
          // Extract content inside code blocks
          // Using a regex to remove only the first line if it contains language specifier
          const content = part.slice(3, -3).replace(/^(\w+\s*)?\n/, ''); 
          return (
            <pre key={i} className="my-4 bg-slate-950 p-4 rounded-lg overflow-x-auto border border-slate-800 shadow-inner">
              <code className="text-emerald-400 font-mono text-sm">{content}</code>
            </pre>
          );
        }
        
        // Regular text handling
        return (
          <React.Fragment key={i}>
            {part.split('\n').map((line, j) => {
              if (!line.trim()) return <div key={j} className="h-3"></div>;

              // Parse bold text: **text**
              const boldParts = line.split(/(\*\*.*?\*\*)/g);
              
              return (
                <p key={j} className="mb-2">
                   {boldParts.map((bPart, k) => {
                     if (bPart.startsWith('**') && bPart.endsWith('**')) {
                       return <strong key={k} className="text-white font-bold">{bPart.slice(2, -2)}</strong>;
                     }
                     return bPart;
                   })}
                </p>
              );
            })}
          </React.Fragment>
        );
      })}
    </div>
  );
};

const Sources: React.FC<{ sources: GroundingSource[] }> = ({ sources }) => {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="mt-4 pt-3 border-t border-slate-700/50">
      <div className="flex items-center space-x-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
        <Globe className="w-3 h-3" />
        <span>Sources</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {sources.map((source, idx) => (
          <a 
            key={idx}
            href={source.uri}
            target="_blank"
            rel="noreferrer"
            className="flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 px-3 py-1.5 rounded-full text-xs transition-colors max-w-xs truncate group"
          >
             <span className="truncate max-w-[200px] group-hover:text-white transition-colors">{source.title}</span>
          </a>
        ))}
      </div>
    </div>
  );
};

interface ChatMessageProps {
  message: ChatMessage;
}

const ChatMessageItem: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} mb-6`}>
      <div className={`flex max-w-4xl w-full ${isUser ? 'flex-row-reverse' : 'flex-row'} gap-4`}>
        {/* Avatar */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center shadow-md ${isUser ? 'bg-primary' : 'bg-emerald-600'}`}>
          {isUser ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
        </div>

        {/* Content */}
        <div className={`flex-1 overflow-hidden rounded-2xl p-4 shadow-sm ${
          isUser 
            ? 'bg-slate-700 text-white rounded-tr-none' 
            : 'bg-surface border border-slate-700 rounded-tl-none'
        }`}>
          {isUser ? (
             <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
          ) : (
            <>
              <FormattedText text={message.content} />
              <Sources sources={message.groundingSources || []} />
            </>
          )}
          
          {/* Timestamp */}
          <div className={`text-[10px] mt-2 opacity-50 ${isUser ? 'text-right' : 'text-left'}`}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessageItem;