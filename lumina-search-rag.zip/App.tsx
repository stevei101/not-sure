import React, { useState, useRef, useEffect } from 'react';
import { RAGDocument, ChatMessage } from './types';
import Sidebar from './components/Sidebar';
import ChatMessageItem from './components/ChatMessage';
import { streamGeminiResponse } from './services/geminiService';
import { Menu, Send, Search, Sparkles, AlertCircle } from 'lucide-react';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [documents, setDocuments] = useState<RAGDocument[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useWebSearch, setUseWebSearch] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input.trim(),
      timestamp: Date.now()
    };

    const initialBotMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'model',
      content: '',
      timestamp: Date.now(),
      isStreaming: true
    };

    setMessages(prev => [...prev, userMsg, initialBotMsg]);
    setInput('');
    setIsLoading(true);
    setError(null);
    
    // Reset textarea height to min-height, then adjust if needed after content
    if (inputRef.current) {
        inputRef.current.style.height = 'auto'; // Temporarily auto to calculate scrollHeight
        inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
        if (inputRef.current.scrollHeight <= 56) { // if content fits within min-height, ensure it's min-height
            inputRef.current.style.height = '56px';
        }
    }

    await streamGeminiResponse(
      messages, // Pass previous history
      userMsg.content,
      documents,
      useWebSearch,
      (textChunk) => {
        setMessages(prev => prev.map(msg => 
          msg.id === initialBotMsg.id 
            ? { ...msg, content: textChunk } 
            : msg
        ));
      },
      (finalText, sources) => {
        setMessages(prev => prev.map(msg => 
          msg.id === initialBotMsg.id 
            ? { ...msg, content: finalText, isStreaming: false, groundingSources: sources } 
            : msg
        ));
        setIsLoading(false);
      },
      (err) => {
        setError(err.message);
        setMessages(prev => prev.map(msg => 
            msg.id === initialBotMsg.id 
              ? { ...msg, content: "Sorry, I encountered an error while processing your request.", isStreaming: false } 
              : msg
          ));
        setIsLoading(false);
      }
    );
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Auto-resize textarea
  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setInput(e.target.value);
      e.target.style.height = 'auto';
      e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden selection:bg-primary/30">
      {/* Sidebar Overlay for Mobile */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <Sidebar 
        documents={documents}
        setDocuments={setDocuments}
        isOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col w-full min-w-0">
        
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-slate-800 bg-background/80 backdrop-blur-md z-20 sticky top-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={toggleSidebar}
              className="p-2 text-slate-400 hover:text-white lg:hidden"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                    Lumina
                </h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <label className="flex items-center cursor-pointer gap-2 text-sm text-slate-400 hover:text-white transition-colors">
              <span className="hidden sm:inline">Web Search</span>
              <div className="relative">
                <input 
                  type="checkbox" 
                  className="sr-only peer"
                  checked={useWebSearch}
                  onChange={(e) => setUseWebSearch(e.target.checked)}
                />
                <div className="w-10 h-6 bg-slate-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
              </div>
            </label>
          </div>
        </header>

        {/* Chat Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 scroll-smooth">
          <div className="max-w-4xl mx-auto h-full flex flex-col">
            
            {messages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 opacity-0 animate-[fadeIn_0.5s_ease-out_forwards]" style={{ animationFillMode: 'forwards' }}>
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-700 border border-slate-600 flex items-center justify-center mb-8 shadow-2xl">
                    <Search className="w-10 h-10 text-primary" />
                </div>
                <h2 className="text-3xl font-bold text-white mb-4">What do you want to know?</h2>
                <p className="text-slate-400 max-w-md mb-8">
                  Ask me anything. I can search the web for real-time info or answer questions based on documents you upload in the sidebar.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-2xl">
                    {[
                        "Explain quantum computing simply",
                        "Latest news on space exploration",
                        "Summarize the uploaded agreement",
                        "Find react tutorials for 2024"
                    ].map((suggestion) => (
                        <button 
                            key={suggestion}
                            onClick={() => {
                                setInput(suggestion);
                            }}
                            className="p-4 bg-surface hover:bg-slate-700 border border-slate-700 rounded-xl text-left text-sm text-slate-300 transition-all hover:scale-[1.02]"
                        >
                            {suggestion}
                        </button>
                    ))}
                </div>
              </div>
            ) : (
              <div className="space-y-6 pb-20">
                {messages.map(msg => (
                  <ChatMessageItem key={msg.id} message={msg} />
                ))}
                {error && (
                    <div className="flex items-center gap-2 p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                        <AlertCircle className="w-4 h-4" />
                        {error}
                    </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
        </main>

        {/* Input Area */}
        <div className="p-4 border-t border-slate-800 bg-background/95 backdrop-blur z-20">
          <div className="max-w-4xl mx-auto relative">
            <textarea
                ref={inputRef}
                value={input}
                onChange={handleInput}
                onKeyDown={handleKeyDown}
                placeholder={documents.length > 0 ? "Ask questions about your documents..." : "Ask anything..."}
                rows={1}
                className="w-full bg-surface text-white placeholder-slate-500 rounded-2xl pl-5 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none border border-slate-700 shadow-lg max-h-[200px]"
                style={{ minHeight: '56px' }}
            />
            <button
                onClick={handleSendMessage}
                disabled={!input.trim() || isLoading}
                className={`absolute right-3 bottom-3 p-2 rounded-xl transition-all ${
                    input.trim() && !isLoading 
                    ? 'bg-primary text-white hover:bg-blue-600 shadow-lg shadow-blue-500/20' 
                    : 'bg-slate-700 text-slate-500 cursor-not-allowed'
                }`}
            >
                {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                    <Send className="w-5 h-5" />
                )}
            </button>
          </div>
          <div className="max-w-4xl mx-auto mt-2 flex justify-center">
            <span className="text-[10px] text-slate-600">
                Powered by Gemini 2.5 Flash • {documents.length} document{documents.length !== 1 ? 's' : ''} loaded
            </span>
          </div>
        </div>

      </div>
    </div>
  );
}

export default App;