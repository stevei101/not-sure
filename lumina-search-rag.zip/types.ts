export interface RAGDocument {
  id: string;
  name: string;
  content: string;
  size: number;
  type: string;
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  isStreaming?: boolean;
  groundingSources?: GroundingSource[];
}

export interface GenerationConfig {
  useWebSearch: boolean;
  temperature: number;
}