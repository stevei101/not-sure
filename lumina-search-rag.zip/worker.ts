import { IttyRouter, IRequest } from 'itty-router';
import { RAGDocument } from './types';

// Define types for worker environment and request body
interface Env {
  AI_GATEWAY_URL: string;
  GEMINI_API_KEY: string;
}

interface BackendChatMessage {
  role: 'user' | 'model';
  content: string;
}

interface GenerationRequest {
  history: BackendChatMessage[];
  currentQuery: string;
  documents: Pick<RAGDocument, 'name' | 'content'>[];
  useWebSearch: boolean;
}

const router = IttyRouter();

// CORS Preflight
router.options('*', () => {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
});

// Main generation endpoint
router.post('/api/generate', async (request: IRequest, env: Env) => {
  try {
    const body: GenerationRequest = await request.json();
    const { history, currentQuery, documents, useWebSearch } = body;

    let systemContext = `You are Lumina, an intelligent AI research assistant. Your goal is to provide accurate, comprehensive, and well-structured answers. Format your response in clean Markdown. Use bolding for key concepts.`;

    if (documents && documents.length > 0) {
      systemContext += `\n\n### User's Knowledge Base (Context) ###\nAnswers should be primarily derived from the following documents. Cite the document title if applicable.\n\n`;
      documents.forEach((doc, index) => {
        systemContext += `<document index="${index + 1}" title="${doc.name}">\n${doc.content}\n</document>\n\n`;
      });
      systemContext += `\nIf the answer is found in the documents, rely on them. If not, utilize your general knowledge or web search (if enabled) to answer the user's question.`;
    }

    const contents = history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.content }]
    }));
    contents.push({
      role: 'user',
      parts: [{ text: currentQuery }]
    });

    const modelId = 'gemini-2.5-flash';
    const geminiUrl = `${env.AI_GATEWAY_URL}/v1beta/models/${modelId}:streamGenerateContent?key=${env.GEMINI_API_KEY}&alt=sse`;

    const geminiRequestPayload = {
      contents,
      systemInstruction: {
        parts: [{ text: systemContext }]
      },
      tools: useWebSearch ? [{ googleSearch: {} }] : undefined,
      generationConfig: {
        temperature: 0.7,
      }
    };

    const geminiResponse = await fetch(geminiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(geminiRequestPayload),
    });

    if (!geminiResponse.ok || !geminiResponse.body) {
      const errorText = await geminiResponse.text();
      console.error("Gemini API Error:", errorText);
      const errResp = new Response(JSON.stringify({ error: `Gemini API error: ${geminiResponse.status} ${errorText}` }), { status: 500 });
      errResp.headers.set('Access-Control-Allow-Origin', '*');
      return errResp;
    }

    const { readable, writable } = new TransformStream();
    geminiResponse.body.pipeTo(writable);

    const response = new Response(readable, {
      headers: { 
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*',
      }
    });

    return response;

  } catch (error: any) {
    console.error("Worker Error:", error);
    const errResp = new Response(JSON.stringify({ error: error.message }), { status: 500 });
    errResp.headers.set('Access-Control-Allow-Origin', '*');
    return errResp;
  }
});

router.all('*', () => new Response('Not Found.', { status: 404 }));

export default {
  fetch: router.handle,
};
