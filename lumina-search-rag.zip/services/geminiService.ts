import { RAGDocument, ChatMessage, GroundingSource } from "../types";

const parseSseChunk = (chunk: string): { text: string, sources: GroundingSource[] } => {
  if (!chunk.startsWith('data:')) {
    return { text: '', sources: [] };
  }

  try {
    const data = JSON.parse(chunk.substring(5)); // remove "data:"
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    
    const chunks = data.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const sources: GroundingSource[] = [];
    if (chunks) {
        chunks.forEach((chunk: any) => {
            if (chunk.web?.uri && chunk.web?.title) {
            sources.push({
                uri: chunk.web.uri,
                title: chunk.web.title
            });
            }
        });
    }

    return { text, sources };

  } catch (e) {
    console.error("Failed to parse SSE chunk:", chunk, e);
    return { text: '', sources: [] };
  }
};


export const streamGeminiResponse = async (
  history: ChatMessage[],
  currentQuery: string,
  documents: RAGDocument[],
  useWebSearch: boolean,
  onChunk: (text: string) => void,
  onComplete: (fullText: string, sources: GroundingSource[]) => void,
  onError: (error: Error) => void
) => {
  try {
    const requestBody = {
      history: history.map(({ role, content }) => ({ role, content })), // Send only what's needed
      currentQuery,
      documents: documents.map(({ name, content }) => ({ name, content })), // Send only what's needed
      useWebSearch,
    };

    const response = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok || !response.body) {
      const errorText = await response.text();
      throw new Error(`API Error: ${response.status} ${errorText}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";
    let finalSources: GroundingSource[] = [];
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      
      buffer = lines.pop() || ""; 

      for (const line of lines) {
        if (line.trim()) {
            const { text, sources } = parseSseChunk(line);
            fullText += text;
            if (sources.length > 0) {
                finalSources = sources;
            }
            onChunk(fullText);
        }
      }
    }

    if (buffer.trim()) {
        const { text, sources } = parseSseChunk(buffer);
        fullText += text;
        if (sources.length > 0) {
            finalSources = sources;
        }
    }
    
    onComplete(fullText, finalSources);

  } catch (error: any) {
    console.error("Streaming Error:", error);
    onError(error instanceof Error ? error : new Error("An unknown streaming error occurred"));
  }
};
